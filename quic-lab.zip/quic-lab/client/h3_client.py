import argparse
import asyncio
import ssl
from dataclasses import dataclass, field
from typing import Dict, List, Tuple
from urllib.parse import urlparse

from aioquic.asyncio.client import connect
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.h3.connection import H3_ALPN, H3Connection
from aioquic.h3.events import DataReceived, HeadersReceived, H3Event
from aioquic.quic.configuration import QuicConfiguration


@dataclass
class ResponseBuffer:
    """缓存单个请求流的响应数据。"""

    headers: List[Tuple[bytes, bytes]] = field(default_factory=list)    
    body: bytearray = field(default_factory=bytearray)
    finished: asyncio.Event = field(default_factory=asyncio.Event)


class SimpleH3Client(QuicConnectionProtocol):
    """最小 HTTP/3 客户端协议：发送 GET 并收集响应。"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._h3 = H3Connection(self._quic)
        self._responses: Dict[int, ResponseBuffer] = {}

    async def get(self, authority: str, path: str) -> ResponseBuffer:
        # 1) 新开一个双向流，存放本次请求的响应缓存
        stream_id = self._quic.get_next_available_stream_id()
        response = ResponseBuffer()
        self._responses[stream_id] = response

        # 2) 发送 HTTP/3 请求头（伪首部 + 普通首部）
        headers = [
            (b":method", b"GET"),
            (b":scheme", b"https"),
            (b":authority", authority.encode("utf-8")),
            (b":path", path.encode("utf-8")),
            (b"user-agent", b"quic-lab-simple-client"),
        ]
        self._h3.send_headers(stream_id=stream_id, headers=headers, end_stream=True)
        self.transmit()

        # 3) 等待该流收完响应
        await response.finished.wait()
        return response

    def quic_event_received(self, event) -> None:
        # QUIC 层事件继续交给 H3 层解析
        for http_event in self._h3.handle_event(event):
            self._handle_http_event(http_event)

    def _handle_http_event(self, http_event: H3Event) -> None:
        if isinstance(http_event, HeadersReceived):
            response = self._responses.get(http_event.stream_id)
            if response:
                response.headers.extend(http_event.headers)
                if http_event.stream_ended:
                    response.finished.set()

        elif isinstance(http_event, DataReceived):
            response = self._responses.get(http_event.stream_id)
            if response:
                response.body.extend(http_event.data)
                if http_event.stream_ended:
                    response.finished.set()


def build_path(parsed) -> str:
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="简单 HTTP/3 客户端示例（中文注释版）")
    parser.add_argument("--url", default="https://localhost:4433/", help="目标 URL")
    parser.add_argument(
        "--insecure",
        action="store_true",
        help="忽略服务端证书校验（仅建议本地实验使用）",
    )
    parser.add_argument("--ca-cert", help="自定义 CA 证书路径（PEM）")
    return parser.parse_args()


async def run() -> None:
    args = parse_args()
    parsed = urlparse(args.url)

    if parsed.scheme != "https":
        raise ValueError("HTTP/3 需要 https:// URL")
    if not parsed.hostname:
        raise ValueError("URL 缺少主机名")

    host = parsed.hostname
    port = parsed.port or 443
    authority = parsed.netloc
    path = build_path(parsed)

    config = QuicConfiguration(alpn_protocols=H3_ALPN, is_client=True)
    if args.insecure:
        config.verify_mode = ssl.CERT_NONE
    elif args.ca_cert:
        config.load_verify_locations(args.ca_cert)

    async with connect(
        host=host,
        port=port,
        configuration=config,
        create_protocol=SimpleH3Client,
        server_name=host,
        wait_connected=True,
    ) as protocol:
        client = protocol
        response = await client.get(authority=authority, path=path)

    print("=== 响应头 ===")
    for key, value in response.headers:
        print(f"{key.decode('utf-8', errors='ignore')}: {value.decode('utf-8', errors='ignore')}")

    print("\n=== 响应体 ===")
    print(response.body.decode("utf-8", errors="replace"))


if __name__ == "__main__":
    asyncio.run(run())


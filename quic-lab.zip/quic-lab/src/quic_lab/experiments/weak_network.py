from __future__ import annotations

import argparse
import platform
import shutil
import subprocess
from dataclasses import dataclass


@dataclass
class NetemProfile:
    delay_ms: float | None = None
    loss_pct: float | None = None
    rate_kbit: int | None = None


def _ensure_tc_available() -> None:
    if platform.system().lower() != "linux":
        raise RuntimeError("tc netem is only supported on Linux.")
    if shutil.which("tc") is None:
        raise RuntimeError("tc command not found. Install iproute2 first.")


def apply_profile(interface: str, profile: NetemProfile) -> None:
    _ensure_tc_available()
    command = ["tc", "qdisc", "replace", "dev", interface, "root", "netem"]

    has_setting = False
    if profile.delay_ms is not None:
        command.extend(["delay", f"{profile.delay_ms}ms"])
        has_setting = True
    if profile.loss_pct is not None:
        command.extend(["loss", f"{profile.loss_pct}%"])
        has_setting = True
    if profile.rate_kbit is not None:
        command.extend(["rate", f"{profile.rate_kbit}kbit"])
        has_setting = True

    if not has_setting:
        raise ValueError("At least one netem setting is required.")

    subprocess.run(command, check=True)


def clear_profile(interface: str) -> None:
    _ensure_tc_available()
    subprocess.run(["tc", "qdisc", "del", "dev", interface, "root"], check=True)


def show_profile(interface: str) -> str:
    _ensure_tc_available()
    proc = subprocess.run(
        ["tc", "qdisc", "show", "dev", interface],
        check=True,
        capture_output=True,
        text=True,
    )
    return proc.stdout.strip()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Manage weak network with tc netem.")
    parser.add_argument("--interface", default="lo", help="Network interface, e.g. lo or eth0")
    sub = parser.add_subparsers(dest="action", required=True)

    apply_parser = sub.add_parser("apply", help="Apply netem profile")
    apply_parser.add_argument("--delay-ms", type=float, help="Delay in milliseconds")
    apply_parser.add_argument("--loss-pct", type=float, help="Packet loss percentage")
    apply_parser.add_argument("--rate-kbit", type=int, help="Rate limit in kbit")

    sub.add_parser("clear", help="Clear netem profile")
    sub.add_parser("show", help="Show current qdisc")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = _build_parser().parse_args(argv)
    try:
        if args.action == "apply":
            profile = NetemProfile(
                delay_ms=args.delay_ms,
                loss_pct=args.loss_pct,
                rate_kbit=args.rate_kbit,
            )
            apply_profile(args.interface, profile)
            print(f"[weak-network] applied on {args.interface}")
            return

        if args.action == "clear":
            clear_profile(args.interface)
            print(f"[weak-network] cleared on {args.interface}")
            return

        output = show_profile(args.interface)
        print(output)
    except RuntimeError as exc:
        raise SystemExit(f"[weak-network] {exc}") from exc


if __name__ == "__main__":
    main()

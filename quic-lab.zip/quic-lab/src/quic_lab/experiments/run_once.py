from __future__ import annotations

import argparse
import asyncio
import json
import re
import ssl
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import yaml
from aioquic.asyncio import serve
from aioquic.asyncio.client import connect
from aioquic.h3.connection import H3_ALPN
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.logger import QuicLogger

from quic_lab.analyzer.metrics import MetricsResult, compute_metrics_for_input
from quic_lab.analyzer.report import build_markdown_report, build_text_report
from quic_lab.client.h3_client import SimpleH3Client, build_path, write_qlog as write_client_qlog
from quic_lab.server.h3_server import SimpleH3Server, write_qlog as write_server_qlog


@dataclass
class RunArtifacts:
    run_id: str
    run_dir: Path
    qlog_dir: Path
    report_text_path: Path
    report_markdown_path: Path
    metrics_json_path: Path
    summary_json_path: Path
    metrics: list[MetricsResult]
    response_status: str | None
    response_body: str


def load_config(config_path: str | Path) -> dict[str, Any]:
    config_file = Path(config_path)
    with open(config_file, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _safe_label(label: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z_-]+", "_", label).strip("_")
    return cleaned or "run"


def _new_run_id(label: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{_safe_label(label)}_{stamp}"


def _resolve_path(path_like: str | Path, base_dir: Path) -> Path:
    path = Path(path_like)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


async def _run_client_server_once(
    settings: dict[str, Any],
    qlog_dir: Path,
    base_dir: Path,
    url_override: str | None,
    insecure_override: bool | None,
    ca_cert_override: str | None,
) -> tuple[str | None, str]:
    server_cfg = settings.get("server", {})
    client_cfg = settings.get("client", {})

    host = str(server_cfg.get("host", "localhost"))
    port = int(server_cfg.get("port", 4433))
    cert_path = _resolve_path(server_cfg.get("cert", "certs/cert.pem"), base_dir)
    key_path = _resolve_path(server_cfg.get("key", "certs/key.pem"), base_dir)

    target_url = url_override or client_cfg.get("target", f"https://{host}:{port}/")
    parsed = urlparse(target_url)
    if parsed.scheme != "https":
        raise ValueError("target URL must use https://")
    if not parsed.hostname:
        raise ValueError("target URL is missing host")

    target_host = parsed.hostname
    target_port = parsed.port or 443
    authority = parsed.netloc or f"{target_host}:{target_port}"
    path = build_path(parsed)

    server_logger = QuicLogger()
    server_quic_config = QuicConfiguration(
        alpn_protocols=H3_ALPN,
        is_client=False,
        quic_logger=server_logger,
    )
    server_quic_config.load_cert_chain(str(cert_path), str(key_path))

    server = await serve(
        host=host,
        port=port,
        configuration=server_quic_config,
        create_protocol=SimpleH3Server,
    )

    try:
        client_logger = QuicLogger()
        client_quic_config = QuicConfiguration(
            alpn_protocols=H3_ALPN,
            is_client=True,
            quic_logger=client_logger,
            server_name=target_host,
        )

        insecure = bool(client_cfg.get("insecure", False))
        if insecure_override is not None:
            insecure = insecure_override

        ca_cert = ca_cert_override or client_cfg.get("ca_cert") or str(cert_path)
        if insecure:
            client_quic_config.verify_mode = ssl.CERT_NONE
        else:
            client_quic_config.load_verify_locations(str(_resolve_path(ca_cert, base_dir)))

        async with connect(
            host=target_host,
            port=target_port,
            configuration=client_quic_config,
            create_protocol=SimpleH3Client,
            wait_connected=True,
        ) as protocol:
            client = protocol
            response = await client.get(authority=authority, path=path)
    finally:
        server.close()

    write_server_qlog(server_logger, qlog_dir, "server")
    write_client_qlog(client_logger, qlog_dir, "client")

    status: str | None = None
    for key, value in response.headers:
        if key == b":status":
            status = value.decode("utf-8", errors="ignore")
            break
    body_text = response.body.decode("utf-8", errors="replace")
    return status, body_text


def run_once(
    config_path: str = "config/default.yaml",
    output_root: str = "output",
    label: str = "run",
    url_override: str | None = None,
    insecure_override: bool | None = None,
    ca_cert_override: str | None = None,
) -> RunArtifacts:
    base_dir = Path.cwd()
    settings = load_config(config_path)

    run_id = _new_run_id(label)
    run_dir = _resolve_path(Path(output_root) / "runs" / run_id, base_dir)
    qlog_dir = run_dir / "qlogs"
    run_dir.mkdir(parents=True, exist_ok=True)
    qlog_dir.mkdir(parents=True, exist_ok=True)

    status, body = asyncio.run(
        _run_client_server_once(
            settings=settings,
            qlog_dir=qlog_dir,
            base_dir=base_dir,
            url_override=url_override,
            insecure_override=insecure_override,
            ca_cert_override=ca_cert_override,
        )
    )

    metrics = compute_metrics_for_input(str(qlog_dir))
    text_report = build_text_report(metrics)
    markdown_report = build_markdown_report(metrics)

    report_text_path = run_dir / "report.txt"
    report_markdown_path = run_dir / "report.md"
    metrics_json_path = run_dir / "metrics.json"
    summary_json_path = run_dir / "summary.json"

    report_text_path.write_text(text_report + "\n", encoding="utf-8")
    report_markdown_path.write_text(markdown_report + "\n", encoding="utf-8")
    metrics_json_path.write_text(
        json.dumps([asdict(m) for m in metrics], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    summary_json_path.write_text(
        json.dumps(
            {
                "run_id": run_id,
                "status": status,
                "response_body_preview": body[:200],
                "qlog_dir": str(qlog_dir),
                "report_text": str(report_text_path),
                "report_markdown": str(report_markdown_path),
                "metrics_json": str(metrics_json_path),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    return RunArtifacts(
        run_id=run_id,
        run_dir=run_dir,
        qlog_dir=qlog_dir,
        report_text_path=report_text_path,
        report_markdown_path=report_markdown_path,
        metrics_json_path=metrics_json_path,
        summary_json_path=summary_json_path,
        metrics=metrics,
        response_status=status,
        response_body=body,
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run one end-to-end QUIC experiment.")
    parser.add_argument("--config", default="config/default.yaml", help="Path to YAML config")
    parser.add_argument("--output-root", default="output", help="Output root directory")
    parser.add_argument("--label", default="run", help="Run label in output folder name")
    parser.add_argument("--url", help="Override client target URL")
    parser.add_argument("--insecure", action="store_true", help="Disable server certificate checks")
    parser.add_argument("--ca-cert", help="Override CA cert path")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = _build_parser().parse_args(argv)
    artifacts = run_once(
        config_path=args.config,
        output_root=args.output_root,
        label=args.label,
        url_override=args.url,
        insecure_override=True if args.insecure else None,
        ca_cert_override=args.ca_cert,
    )

    print(f"[run] completed: {artifacts.run_id}")
    print(f"[run] HTTP status: {artifacts.response_status}")
    print(f"[run] qlogs: {artifacts.qlog_dir}")
    print(f"[run] text report: {artifacts.report_text_path}")
    print(f"[run] markdown report: {artifacts.report_markdown_path}")
    print(f"[run] metrics json: {artifacts.metrics_json_path}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from statistics import mean
from typing import Any
from urllib.parse import urlparse

from quic_lab.baseline.h2_client import run_h2_baseline
from quic_lab.experiments.multiplexing import run_multiplexing
from quic_lab.experiments.run_once import load_config
from quic_lab.experiments.weak_network import NetemProfile, apply_profile, clear_profile


@dataclass
class Scenario:
    name: str
    delay_ms: float | None = None
    loss_pct: float | None = None
    rate_kbit: int | None = None


@dataclass
class ComparisonRow:
    scenario: str
    round: int
    protocol: str
    status: str
    handshake_ms: float | None
    avg_completion_ms: float | None
    avg_ttfb_ms: float | None
    recovery_ms: float | None
    packet_dropped: int | None
    retransmission_events: int | None
    run_dir: str


def _fmt_ms(value: float | None) -> str:
    if value is None:
        return "N/A"
    return f"{value:.3f}"


def _fmt_int(value: int | None) -> str:
    if value is None:
        return "N/A"
    return str(value)


def _parse_protocols(raw: str) -> list[str]:
    values = [item.strip().lower() for item in raw.split(",") if item.strip()]
    allowed = {"quic", "h2"}
    protocols: list[str] = []
    for value in values:
        if value not in allowed:
            raise ValueError(f"Unsupported protocol: {value}. Allowed: quic,h2")
        if value not in protocols:
            protocols.append(value)
    if not protocols:
        raise ValueError("No protocol selected. Use --protocol quic,h2")
    return protocols


def _normalize_paths(path_args: list[str] | None, fallback_url: str) -> list[str]:
    if path_args:
        paths: list[str] = []
        for raw in path_args:
            for item in raw.split(","):
                path = item.strip()
                if not path:
                    continue
                if not path.startswith("/"):
                    path = "/" + path
                paths.append(path)
        if paths:
            return paths

    parsed = urlparse(fallback_url)
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return [path]


def _default_scenarios() -> list[Scenario]:
    return [
        Scenario(name="baseline"),
        Scenario(name="delay_50ms", delay_ms=50),
        Scenario(name="loss_1pct", loss_pct=1.0),
    ]


def _load_scenarios(config_path: str) -> list[Scenario]:
    settings = load_config(config_path)
    raw_profiles = settings.get("experiments", {}).get("profiles")
    if not isinstance(raw_profiles, list) or not raw_profiles:
        return _default_scenarios()

    scenarios: list[Scenario] = []
    for i, item in enumerate(raw_profiles, start=1):
        if not isinstance(item, dict):
            continue
        scenarios.append(
            Scenario(
                name=str(item.get("name", f"profile_{i}")),
                delay_ms=item.get("delay_ms"),
                loss_pct=item.get("loss_pct"),
                rate_kbit=item.get("rate_kbit"),
            )
        )
    return scenarios or _default_scenarios()


def _needs_netem(s: Scenario) -> bool:
    return s.delay_ms is not None or s.loss_pct is not None or s.rate_kbit is not None


def _build_markdown(rows: list[ComparisonRow]) -> str:
    lines = [
        "| scenario | round | protocol | status | handshake_ms | avg_completion_ms | avg_ttfb_ms | recovery_ms | packet_dropped | retransmissions | run_dir |",
        "|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        lines.append(
            "| "
            f"{row.scenario} | {row.round} | {row.protocol} | {row.status} | "
            f"{_fmt_ms(row.handshake_ms)} | {_fmt_ms(row.avg_completion_ms)} | "
            f"{_fmt_ms(row.avg_ttfb_ms)} | {_fmt_ms(row.recovery_ms)} | "
            f"{_fmt_int(row.packet_dropped)} | {_fmt_int(row.retransmission_events)} | "
            f"{row.run_dir} |"
        )
    return "\n".join(lines)


def _summarize_status(statuses: list[str | int | None]) -> str:
    flat = [str(item) for item in statuses if item is not None]
    if not flat:
        return "N/A"
    unique = sorted(set(flat))
    if len(unique) == 1:
        return unique[0]
    return ",".join(unique)


def _run_quic_round(
    config_path: str,
    output_root: str,
    label: str,
    paths: list[str],
    url_override: str | None,
) -> ComparisonRow:
    artifacts = run_multiplexing(
        config_path=config_path,
        output_root=output_root,
        label=label,
        paths=paths,
        url_override=url_override,
    )

    client_metrics = [m for m in artifacts.metrics if m.role == "client"]
    client_metric = client_metrics[0] if client_metrics else None

    completion_values = [s.elapsed_ms for s in artifacts.stream_results if s.elapsed_ms is not None]
    avg_completion = mean(completion_values) if completion_values else None
    recovery_ms = None
    if len(completion_values) >= 2:
        recovery_ms = max(completion_values) - min(completion_values)

    retransmissions: int | None = None
    packet_dropped: int | None = None
    handshake_ms: float | None = None
    avg_ttfb_ms: float | None = None
    if client_metric is not None:
        retransmissions = sum(item.retransmission_events for item in client_metric.per_stream)
        packet_dropped = client_metric.packet_dropped_events
        handshake_ms = client_metric.handshake_duration_ms
        avg_ttfb_ms = client_metric.ttfb_ms

    return ComparisonRow(
        scenario="",
        round=0,
        protocol="quic",
        status=_summarize_status([item.status for item in artifacts.stream_results]),
        handshake_ms=handshake_ms,
        avg_completion_ms=avg_completion,
        avg_ttfb_ms=avg_ttfb_ms,
        recovery_ms=recovery_ms,
        packet_dropped=packet_dropped,
        retransmission_events=retransmissions,
        run_dir=str(artifacts.run_dir),
    )


def _run_h2_round(
    config_path: str,
    output_root: str,
    label: str,
    paths: list[str],
    url_override: str | None,
) -> ComparisonRow:
    artifacts = run_h2_baseline(
        config_path=config_path,
        output_root=output_root,
        label=label,
        paths=paths,
        url_override=url_override,
    )

    completion_values = [item.completion_ms for item in artifacts.request_results]
    ttfb_values = [item.ttfb_ms for item in artifacts.request_results]
    avg_completion = mean(completion_values) if completion_values else None
    avg_ttfb_ms = mean(ttfb_values) if ttfb_values else None
    recovery_ms = None
    if len(completion_values) >= 2:
        recovery_ms = max(completion_values) - min(completion_values)

    return ComparisonRow(
        scenario="",
        round=0,
        protocol="h2",
        status=_summarize_status([item.status_code for item in artifacts.request_results]),
        handshake_ms=artifacts.handshake_ms,
        avg_completion_ms=avg_completion,
        avg_ttfb_ms=avg_ttfb_ms,
        recovery_ms=recovery_ms,
        packet_dropped=None,
        retransmission_events=None,
        run_dir=str(artifacts.run_dir),
    )


def run_compare(
    config_path: str = "config/default.yaml",
    output_root: str = "output",
    interface: str = "lo",
    rounds: int = 1,
    enable_netem: bool = True,
    protocol: str = "quic,h2",
    path_args: list[str] | None = None,
    url_override: str | None = None,
) -> Path:
    settings = load_config(config_path)
    fallback_url = url_override or settings.get("client", {}).get("target", "https://localhost:4433/")
    protocols = _parse_protocols(protocol)
    paths = _normalize_paths(path_args, fallback_url=fallback_url)
    scenarios = _load_scenarios(config_path)

    compare_id = datetime.now().strftime("compare_%Y%m%d_%H%M%S")
    compare_dir = Path(output_root) / "compare" / compare_id
    compare_dir.mkdir(parents=True, exist_ok=True)

    rows: list[ComparisonRow] = []
    netem_available = enable_netem

    for scenario in scenarios:
        applied = False
        try:
            if _needs_netem(scenario) and netem_available:
                try:
                    apply_profile(
                        interface,
                        NetemProfile(
                            delay_ms=scenario.delay_ms,
                            loss_pct=scenario.loss_pct,
                            rate_kbit=scenario.rate_kbit,
                        ),
                    )
                    applied = True
                except RuntimeError:
                    netem_available = False

            for round_idx in range(1, rounds + 1):
                for proto in protocols:
                    run_label = f"{scenario.name}_{proto}_r{round_idx}"
                    if proto == "quic":
                        row = _run_quic_round(
                            config_path=config_path,
                            output_root=output_root,
                            label=run_label,
                            paths=paths,
                            url_override=url_override,
                        )
                    else:
                        row = _run_h2_round(
                            config_path=config_path,
                            output_root=output_root,
                            label=run_label,
                            paths=paths,
                            url_override=url_override,
                        )

                    row.scenario = scenario.name
                    row.round = round_idx
                    rows.append(row)
        finally:
            if applied and netem_available:
                clear_profile(interface)

    summary_json_path = compare_dir / "summary.json"
    summary_md_path = compare_dir / "summary.md"

    summary_json_path.write_text(
        json.dumps(
            {
                "protocols": protocols,
                "paths": paths,
                "scenarios": [asdict(s) for s in scenarios],
                "rows": [asdict(row) for row in rows],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    summary_md_path.write_text(_build_markdown(rows) + "\n", encoding="utf-8")
    return compare_dir


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run multi-scenario cross-protocol comparison.")
    parser.add_argument("--config", default="config/default.yaml", help="Path to YAML config")
    parser.add_argument("--output-root", default="output", help="Output root directory")
    parser.add_argument("--interface", default="lo", help="Network interface for tc netem")
    parser.add_argument("--rounds", type=int, default=1, help="Runs per scenario")
    parser.add_argument("--protocol", default="quic,h2", help="Protocol list, e.g. quic,h2")
    parser.add_argument("--path", action="append", help="Request path (repeatable or comma-separated)")
    parser.add_argument("--url", help="Override client target URL")
    parser.add_argument("--no-netem", action="store_true", help="Disable weak-network injection")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = _build_parser().parse_args(argv)
    compare_dir = run_compare(
        config_path=args.config,
        output_root=args.output_root,
        interface=args.interface,
        rounds=args.rounds,
        enable_netem=not args.no_netem,
        protocol=args.protocol,
        path_args=args.path,
        url_override=args.url,
    )
    print(f"[compare] completed: {compare_dir}")
    print(f"[compare] summary: {compare_dir / 'summary.md'}")


if __name__ == "__main__":
    main()

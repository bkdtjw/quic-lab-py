from __future__ import annotations

import argparse
import asyncio
import json
import re
import ssl
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from aioquic.asyncio import serve
from aioquic.asyncio.client import connect
from aioquic.h3.connection import H3_ALPN
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.logger import QuicLogger

from quic_lab.analyzer.metrics import MetricsResult, compute_metrics_for_input
from quic_lab.analyzer.report import build_markdown_report, build_text_report
from quic_lab.client.h3_client import (
    ResponseBuffer,
    SimpleH3Client,
    get_header_value,
    write_qlog as write_client_qlog,
)
from quic_lab.experiments.run_once import load_config
from quic_lab.server.h3_server import SimpleH3Server, write_qlog as write_server_qlog


@dataclass
class MultiplexedStreamResult:
    stream_id: int
    path: str
    status: str | None
    body_bytes: int
    elapsed_ms: float | None


@dataclass
class MultiplexingArtifacts:
    run_id: str
    run_dir: Path
    qlog_dir: Path
    report_text_path: Path
    report_markdown_path: Path
    metrics_json_path: Path
    summary_json_path: Path
    stream_results: list[MultiplexedStreamResult]
    metrics: list[MetricsResult]


def _safe_label(label: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z_-]+", "_", label).strip("_")
    return cleaned or "multiplexing"


def _new_run_id(label: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{_safe_label(label)}_{stamp}"


def _resolve_path(path_like: str | Path, base_dir: Path) -> Path:
    path = Path(path_like)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _normalize_paths(path_args: list[str] | None) -> list[str]:
    if not path_args:
        return [
            "/large?bytes=1048576",
            "/small?bytes=1024",
            "/small?bytes=1024",
            "/small?bytes=1024",
        ]

    normalized: list[str] = []
    for raw in path_args:
        for item in raw.split(","):
            path = item.strip()
            if not path:
                continue
            if not path.startswith("/"):
                path = "/" + path
            normalized.append(path)
    return normalized


def _response_to_result(response: ResponseBuffer) -> MultiplexedStreamResult:
    status = get_header_value(response, ":status")
    elapsed_ms: float | None = None
    if response.ended_at is not None:
        elapsed_ms = (response.ended_at - response.started_at) * 1000
    return MultiplexedStreamResult(
        stream_id=response.stream_id,
        path=response.path,
        status=status,
        body_bytes=len(response.body),
        elapsed_ms=elapsed_ms,
    )


async def _run_multiplexing_once(
    settings: dict[str, Any],
    qlog_dir: Path,
    base_dir: Path,
    paths: list[str],
    url_override: str | None,
    insecure_override: bool | None,
    ca_cert_override: str | None,
) -> list[MultiplexedStreamResult]:
    server_cfg = settings.get("server", {})
    client_cfg = settings.get("client", {})

    host = str(server_cfg.get("host", "localhost"))
    port = int(server_cfg.get("port", 4433))
    cert_path = _resolve_path(server_cfg.get("cert", "certs/cert.pem"), base_dir)
    key_path = _resolve_path(server_cfg.get("key", "certs/key.pem"), base_dir)

    target_url = url_override or client_cfg.get("target", f"https://{host}:{port}/")
    parsed = urlparse(target_url)
    if parsed.scheme != "https":
        raise ValueError("target URL must use https://")
    if not parsed.hostname:
        raise ValueError("target URL is missing host")

    target_host = parsed.hostname
    target_port = parsed.port or 443
    authority = parsed.netloc or f"{target_host}:{target_port}"

    server_logger = QuicLogger()
    server_quic_config = QuicConfiguration(
        alpn_protocols=H3_ALPN,
        is_client=False,
        quic_logger=server_logger,
    )
    server_quic_config.load_cert_chain(str(cert_path), str(key_path))

    server = await serve(
        host=host,
        port=port,
        configuration=server_quic_config,
        create_protocol=SimpleH3Server,
    )

    try:
        client_logger = QuicLogger()
        client_quic_config = QuicConfiguration(
            alpn_protocols=H3_ALPN,
            is_client=True,
            quic_logger=client_logger,
            server_name=target_host,
        )

        insecure = bool(client_cfg.get("insecure", False))
        if insecure_override is not None:
            insecure = insecure_override

        ca_cert = ca_cert_override or client_cfg.get("ca_cert") or str(cert_path)
        if insecure:
            client_quic_config.verify_mode = ssl.CERT_NONE
        else:
            client_quic_config.load_verify_locations(str(_resolve_path(ca_cert, base_dir)))

        async with connect(
            host=target_host,
            port=target_port,
            configuration=client_quic_config,
            create_protocol=SimpleH3Client,
            wait_connected=True,
        ) as protocol:
            client = protocol
            responses = await client.get_many(authority=authority, paths=paths)
    finally:
        server.close()

    write_server_qlog(server_logger, qlog_dir, "server")
    write_client_qlog(client_logger, qlog_dir, "client")
    return [_response_to_result(response) for response in responses]


def run_multiplexing(
    config_path: str = "config/default.yaml",
    output_root: str = "output",
    label: str = "multiplexing",
    paths: list[str] | None = None,
    url_override: str | None = None,
    insecure_override: bool | None = None,
    ca_cert_override: str | None = None,
) -> MultiplexingArtifacts:
    base_dir = Path.cwd()
    settings = load_config(config_path)
    selected_paths = _normalize_paths(paths)
    if not selected_paths:
        raise ValueError("at least one request path is required")

    run_id = _new_run_id(label)
    run_dir = _resolve_path(Path(output_root) / "multiplexing" / run_id, base_dir)
    qlog_dir = run_dir / "qlogs"
    run_dir.mkdir(parents=True, exist_ok=True)
    qlog_dir.mkdir(parents=True, exist_ok=True)

    stream_results = asyncio.run(
        _run_multiplexing_once(
            settings=settings,
            qlog_dir=qlog_dir,
            base_dir=base_dir,
            paths=selected_paths,
            url_override=url_override,
            insecure_override=insecure_override,
            ca_cert_override=ca_cert_override,
        )
    )

    metrics = compute_metrics_for_input(str(qlog_dir))
    text_report = build_text_report(metrics)
    markdown_report = build_markdown_report(metrics)

    report_text_path = run_dir / "report.txt"
    report_markdown_path = run_dir / "report.md"
    metrics_json_path = run_dir / "metrics.json"
    summary_json_path = run_dir / "summary.json"

    report_text_path.write_text(text_report + "\n", encoding="utf-8")
    report_markdown_path.write_text(markdown_report + "\n", encoding="utf-8")
    metrics_json_path.write_text(
        json.dumps([asdict(item) for item in metrics], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    summary_json_path.write_text(
        json.dumps(
            {
                "run_id": run_id,
                "paths": selected_paths,
                "stream_results": [asdict(item) for item in stream_results],
                "qlog_dir": str(qlog_dir),
                "report_text": str(report_text_path),
                "report_markdown": str(report_markdown_path),
                "metrics_json": str(metrics_json_path),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    return MultiplexingArtifacts(
        run_id=run_id,
        run_dir=run_dir,
        qlog_dir=qlog_dir,
        report_text_path=report_text_path,
        report_markdown_path=report_markdown_path,
        metrics_json_path=metrics_json_path,
        summary_json_path=summary_json_path,
        stream_results=stream_results,
        metrics=metrics,
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run one multiplexing experiment over a single QUIC connection.")
    parser.add_argument("--config", default="config/default.yaml", help="Path to YAML config")
    parser.add_argument("--output-root", default="output", help="Output root directory")
    parser.add_argument("--label", default="multiplexing", help="Run label in output folder name")
    parser.add_argument("--path", action="append", help="Request path (repeatable or comma-separated)")
    parser.add_argument("--url", help="Override client target URL")
    parser.add_argument("--insecure", action="store_true", help="Disable server certificate checks")
    parser.add_argument("--ca-cert", help="Override CA cert path")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = _build_parser().parse_args(argv)
    artifacts = run_multiplexing(
        config_path=args.config,
        output_root=args.output_root,
        label=args.label,
        paths=args.path,
        url_override=args.url,
        insecure_override=True if args.insecure else None,
        ca_cert_override=args.ca_cert,
    )

    print(f"[multiplexing] completed: {artifacts.run_id}")
    print(f"[multiplexing] qlogs: {artifacts.qlog_dir}")
    for item in artifacts.stream_results:
        elapsed_text = f"{item.elapsed_ms:.2f} ms" if item.elapsed_ms is not None else "N/A"
        print(
            f"[multiplexing] stream={item.stream_id} path={item.path} "
            f"status={item.status} bytes={item.body_bytes} elapsed={elapsed_text}"
        )
    print(f"[multiplexing] report: {artifacts.report_text_path}")


if __name__ == "__main__":
    main()

import argparse
import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import yaml
from aioquic.asyncio import serve
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.h3.connection import H3_ALPN, H3Connection
from aioquic.h3.events import HeadersReceived, H3Event
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.logger import QuicLogger


def load_config(config_path: str) -> dict[str, Any]:
    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data


def write_qlog(quic_logger: QuicLogger, qlog_dir: Path, role: str) -> Path:
    qlog_dir.mkdir(parents=True, exist_ok=True)
    file_path = qlog_dir / f"{role}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.qlog"
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(quic_logger.to_dict(), f, ensure_ascii=False, indent=2)
    return file_path


def _parse_size(query: dict[str, list[str]], default: int) -> int:
    raw = query.get("bytes", [str(default)])[0]
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = default
    return max(0, min(value, 8 * 1024 * 1024))


def build_response_body(path_value: str) -> bytes:
    parsed = urlparse(path_value)
    query = parse_qs(parsed.query)

    if parsed.path in {"/large", "/small"} or "bytes" in query:
        default_size = 1024 * 1024 if parsed.path == "/large" else 1024
        size = _parse_size(query, default=default_size)
        prefix = f"path={path_value}\n".encode("utf-8")
        if size <= len(prefix):
            return prefix[:size]
        return prefix + (b"x" * (size - len(prefix)))

    return f"hello from quic-lab server, path={path_value}\n".encode("utf-8")


class SimpleH3Server(QuicConnectionProtocol):
    """最小 HTTP/3 服务端：收到 GET 后返回固定文本。"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._h3 = H3Connection(self._quic)

    def quic_event_received(self, event) -> None:
        for http_event in self._h3.handle_event(event):
            self._handle_http_event(http_event)

    def _handle_http_event(self, http_event: H3Event) -> None:
        if not isinstance(http_event, HeadersReceived):
            return

        header_map = {k: v for k, v in http_event.headers}
        method = header_map.get(b":method", b"").decode("utf-8", errors="ignore")
        path = header_map.get(b":path", b"/").decode("utf-8", errors="ignore")

        if method == "GET":
            body = build_response_body(path)
            status = b"200"
        else:
            body = b"method not allowed\n"
            status = b"405"

        headers = [
            (b":status", status),
            (b"server", b"quic-lab"),
            (b"content-type", b"text/plain; charset=utf-8"),
            (b"content-length", str(len(body)).encode("ascii")),
        ]
        self._h3.send_headers(stream_id=http_event.stream_id, headers=headers, end_stream=False)
        self._h3.send_data(stream_id=http_event.stream_id, data=body, end_stream=True)
        self.transmit()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="最小 HTTP/3 服务端")
    parser.add_argument("--config", default="config/default.yaml", help="配置文件路径")
    return parser.parse_args()


async def run() -> None:
    args = parse_args()
    settings = load_config(args.config)

    server_cfg = settings.get("server", {})
    logging_cfg = settings.get("logging", {})

    host = server_cfg.get("host", "localhost")
    port = int(server_cfg.get("port", 4433))
    cert_path = server_cfg.get("cert", "certs/cert.pem")
    key_path = server_cfg.get("key", "certs/key.pem")
    qlog_dir = Path(logging_cfg.get("qlog_dir", "output/qlogs"))

    quic_logger = QuicLogger()
    quic_config = QuicConfiguration(
        alpn_protocols=H3_ALPN,
        is_client=False,
        quic_logger=quic_logger,
    )
    quic_config.load_cert_chain(certfile=cert_path, keyfile=key_path)

    server = await serve(
        host=host,
        port=port,
        configuration=quic_config,
        create_protocol=SimpleH3Server,
    )
    print(f"[server] listening on https://{host}:{port}")

    try:
        await asyncio.Event().wait()
    finally:
        server.close()
        qlog_path = write_qlog(quic_logger=quic_logger, qlog_dir=qlog_dir, role="server")
        print(f"[server] qlog written: {qlog_path}")


def main() -> None:
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        # Ctrl+C 中断时，run() 里的 finally 会负责收尾和写 qlog
        pass


if __name__ == "__main__":
    main()

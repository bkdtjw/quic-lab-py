from __future__ import annotations

import argparse

from quic_lab.experiments.compare import main as compare_main
from quic_lab.experiments.multiplexing import main as multiplexing_main
from quic_lab.experiments.run_once import main as run_once_main
from quic_lab.experiments.weak_network import main as weak_network_main


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m quic_lab",
        description="QUIC lab command line interface.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("run", add_help=False, help="Run one end-to-end experiment")
    sub.add_parser("multiplexing", add_help=False, help="Run multiplexed multi-stream experiment")
    sub.add_parser("weak-network", add_help=False, help="Manage tc netem profile")
    sub.add_parser("compare", add_help=False, help="Run multi-scenario comparison")
    return parser


def main(argv: list[str] | None = None) -> None:
    args, remaining = _build_parser().parse_known_args(argv)
    if args.command == "run":
        run_once_main(remaining)
        return
    if args.command == "multiplexing":
        multiplexing_main(remaining)
        return
    if args.command == "weak-network":
        weak_network_main(remaining)
        return
    compare_main(remaining)


if __name__ == "__main__":
    main()

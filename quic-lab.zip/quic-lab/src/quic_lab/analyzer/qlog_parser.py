from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class QlogEvent:
    time: float
    name: str
    data: dict[str, Any]


@dataclass
class QlogTrace:
    source: Path
    vantage_type: str
    vantage_name: str
    odcid: str | None
    events: list[QlogEvent]


def parse_qlog_file(path: str | Path) -> QlogTrace:
    source = Path(path)
    payload = json.loads(source.read_text(encoding="utf-8"))

    traces = payload.get("traces", [])
    if not traces:
        raise ValueError(f"No traces found in qlog: {source}")

    trace = traces[0]
    vantage = trace.get("vantage_point", {}) or {}
    common_fields = trace.get("common_fields", {}) or {}
    raw_events = trace.get("events", []) or []

    events: list[QlogEvent] = []
    for ev in raw_events:
        events.append(
            QlogEvent(
                time=float(ev.get("time", 0.0)),
                name=str(ev.get("name", "")),
                data=dict(ev.get("data", {}) or {}),
            )
        )

    return QlogTrace(
        source=source,
        vantage_type=str(vantage.get("type", "unknown")),
        vantage_name=str(vantage.get("name", "unknown")),
        odcid=common_fields.get("ODCID"),
        events=events,
    )


def parse_qlog_directory(directory: str | Path) -> list[QlogTrace]:
    root = Path(directory)
    if not root.exists():
        raise FileNotFoundError(f"Directory not found: {root}")

    traces: list[QlogTrace] = []
    for file_path in sorted(root.glob("*.qlog")):
        traces.append(parse_qlog_file(file_path))
    return traces


def parse_input(path: str | Path) -> list[QlogTrace]:
    target = Path(path)
    if target.is_dir():
        return parse_qlog_directory(target)
    return [parse_qlog_file(target)]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Parse qlog into structured events.")
    parser.add_argument("--input", default="sample_logs", help="qlog file or directory")
    return parser


def main() -> None:
    args = _build_parser().parse_args()
    traces = parse_input(args.input)
    for trace in traces:
        print(
            f"{trace.source.name}: role={trace.vantage_type}, "
            f"events={len(trace.events)}, odcid={trace.odcid}"
        )


if __name__ == "__main__":
    main()

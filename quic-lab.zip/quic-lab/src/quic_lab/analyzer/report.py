from __future__ import annotations

import argparse
from pathlib import Path

from quic_lab.analyzer.metrics import MetricsResult, compute_metrics_for_input


def _fmt_ms(value: float | None) -> str:
    if value is None:
        return "N/A"
    return f"{value:.3f}"


def build_text_report(results: list[MetricsResult]) -> str:
    headers = [
        "source",
        "role",
        "events",
        "handshake_ms",
        "ttfb_ms",
        "lost",
        "dropped",
        "cwnd(first->last)",
        "cwnd[min,max]",
    ]
    rows: list[list[str]] = []
    for r in results:
        rows.append(
            [
                r.source,
                r.role,
                str(r.total_events),
                _fmt_ms(r.handshake_duration_ms),
                _fmt_ms(r.ttfb_ms),
                str(r.packet_lost_events),
                str(r.packet_dropped_events),
                f"{r.cwnd_first}->{r.cwnd_last}",
                f"[{r.cwnd_min},{r.cwnd_max}]",
            ]
        )

    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    def render_row(cells: list[str]) -> str:
        return " | ".join(cell.ljust(widths[i]) for i, cell in enumerate(cells))

    divider = "-+-".join("-" * w for w in widths)
    lines = [render_row(headers), divider]
    lines.extend(render_row(r) for r in rows)
    return "\n".join(lines)


def build_markdown_report(results: list[MetricsResult]) -> str:
    lines = [
        "| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in results:
        lines.append(
            "| "
            f"{r.source} | {r.role} | {r.total_events} | {_fmt_ms(r.handshake_duration_ms)} | "
            f"{_fmt_ms(r.ttfb_ms)} | {r.packet_lost_events} | {r.packet_dropped_events} | "
            f"{r.cwnd_first} | {r.cwnd_last} | {r.cwnd_min} | {r.cwnd_max} |"
        )
    return "\n".join(lines)


def render_report(input_path: str, fmt: str) -> str:
    results = compute_metrics_for_input(input_path)
    if fmt == "markdown":
        return build_markdown_report(results)
    return build_text_report(results)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Render qlog metrics report.")
    parser.add_argument("--input", default="sample_logs", help="qlog file or directory")
    parser.add_argument("--format", choices=["text", "markdown"], default="text")
    parser.add_argument("--output", help="Optional output file path")
    return parser


def main() -> None:
    args = _build_parser().parse_args()
    rendered = render_report(args.input, args.format)
    print(rendered)
    if args.output:
        Path(args.output).write_text(rendered + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

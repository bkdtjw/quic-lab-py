from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass, field
from typing import Any

from quic_lab.analyzer.qlog_parser import QlogEvent, QlogTrace, parse_input


@dataclass
class StreamMetricsResult:
    stream_id: int
    request_start_ms: float | None
    response_headers_ms: float | None
    stream_end_ms: float | None
    completion_time_ms: float | None
    payload_bytes: int
    bytes_sent: int
    bytes_received: int
    retransmission_events: int
    throughput_bytes_per_sec: float | None


@dataclass
class MetricsResult:
    source: str
    role: str
    total_events: int
    total_streams: int
    handshake_duration_ms: float | None
    ttfb_ms: float | None
    packet_lost_events: int
    packet_dropped_events: int
    cwnd_first: int | None
    cwnd_last: int | None
    cwnd_min: int | None
    cwnd_max: int | None
    per_stream: list[StreamMetricsResult] = field(default_factory=list)


@dataclass
class _StreamAccumulator:
    request_start_ms: float | None = None
    response_headers_ms: float | None = None
    stream_end_ms: float | None = None
    bytes_sent: int = 0
    bytes_received: int = 0
    retransmission_events: int = 0


def _extract_frames(event: QlogEvent) -> list[dict[str, Any]]:
    frames = event.data.get("frames")
    if isinstance(frames, list):
        return [f for f in frames if isinstance(f, dict)]
    return []


def _first_packet_time(events: list[QlogEvent]) -> float | None:
    for ev in events:
        if ev.name in {"transport:packet_sent", "transport:packet_received"}:
            return ev.time
    return None


def _handshake_done_time(events: list[QlogEvent]) -> float | None:
    for ev in events:
        if ev.name != "transport:packet_received":
            continue
        for frame in _extract_frames(ev):
            if frame.get("frame_type") == "handshake_done":
                return ev.time

    for ev in events:
        if ev.name != "security:key_updated":
            continue
        key_type = str(ev.data.get("key_type", "")).lower()
        if "1rtt" in key_type:
            return ev.time
    return None


def _find_http_markers(events: list[QlogEvent]) -> tuple[float | None, float | None]:
    request_time: float | None = None
    response_time: float | None = None

    for ev in events:
        if ev.name not in {"http:frame_created", "http:frame_parsed"}:
            continue

        frame = ev.data.get("frame")
        if not isinstance(frame, dict):
            continue
        if frame.get("frame_type") != "headers":
            continue

        headers = frame.get("headers", [])
        if not isinstance(headers, list):
            continue

        has_method = False
        has_status = False
        for header in headers:
            if not isinstance(header, dict):
                continue
            name = header.get("name")
            if name == ":method":
                has_method = True
            elif name == ":status":
                has_status = True

        if has_method and request_time is None:
            request_time = ev.time
        if has_status and response_time is None:
            response_time = ev.time

    return request_time, response_time


def _extract_cwnd(events: list[QlogEvent]) -> list[int]:
    values: list[int] = []
    for ev in events:
        if ev.name != "recovery:metrics_updated":
            continue
        cwnd = ev.data.get("cwnd")
        if isinstance(cwnd, (int, float)):
            values.append(int(cwnd))
    return values


def _has_header(headers: list[dict[str, Any]], name: str) -> bool:
    for header in headers:
        if not isinstance(header, dict):
            continue
        if header.get("name") == name:
            return True
    return False


def _collect_stream_metrics(trace: QlogTrace) -> list[StreamMetricsResult]:
    stream_data: dict[int, _StreamAccumulator] = {}
    http_stream_ids: set[int] = set()

    def ensure_stream(stream_id: int) -> _StreamAccumulator:
        if stream_id not in stream_data:
            stream_data[stream_id] = _StreamAccumulator()
        return stream_data[stream_id]

    for ev in trace.events:
        if ev.name in {"http:frame_created", "http:frame_parsed"}:
            frame = ev.data.get("frame")
            stream_id = ev.data.get("stream_id")
            if not isinstance(frame, dict) or not isinstance(stream_id, int):
                continue
            if frame.get("frame_type") != "headers":
                continue

            headers = frame.get("headers", [])
            if not isinstance(headers, list):
                continue
            typed_headers = [h for h in headers if isinstance(h, dict)]
            bucket = ensure_stream(stream_id)
            http_stream_ids.add(stream_id)

            if _has_header(typed_headers, ":method") and bucket.request_start_ms is None:
                bucket.request_start_ms = ev.time
            if _has_header(typed_headers, ":status") and bucket.response_headers_ms is None:
                bucket.response_headers_ms = ev.time
            continue

        if ev.name in {"transport:packet_sent", "transport:packet_received"}:
            is_sent = ev.name == "transport:packet_sent"
            for frame in _extract_frames(ev):
                if frame.get("frame_type") != "stream":
                    continue
                stream_id = frame.get("stream_id")
                if not isinstance(stream_id, int):
                    continue

                bucket = ensure_stream(stream_id)
                frame_len = frame.get("length")
                if isinstance(frame_len, (int, float)):
                    if is_sent:
                        bucket.bytes_sent += int(frame_len)
                    else:
                        bucket.bytes_received += int(frame_len)

                if frame.get("fin") is True:
                    if bucket.stream_end_ms is None or ev.time > bucket.stream_end_ms:
                        bucket.stream_end_ms = ev.time
            continue

        if ev.name in {"recovery:packet_lost", "transport:packet_lost"}:
            for frame in _extract_frames(ev):
                if frame.get("frame_type") != "stream":
                    continue
                stream_id = frame.get("stream_id")
                if not isinstance(stream_id, int):
                    continue
                bucket = ensure_stream(stream_id)
                bucket.retransmission_events += 1

    results: list[StreamMetricsResult] = []
    stream_ids = sorted(http_stream_ids) if http_stream_ids else sorted(stream_data)
    for stream_id in stream_ids:
        bucket = stream_data[stream_id]
        completion_time_ms: float | None = None
        if (
            bucket.request_start_ms is not None
            and bucket.stream_end_ms is not None
            and bucket.stream_end_ms >= bucket.request_start_ms
        ):
            completion_time_ms = bucket.stream_end_ms - bucket.request_start_ms

        if trace.vantage_type == "client":
            payload_bytes = bucket.bytes_received
        elif trace.vantage_type == "server":
            payload_bytes = bucket.bytes_sent
        else:
            payload_bytes = max(bucket.bytes_sent, bucket.bytes_received)

        throughput_bytes_per_sec: float | None = None
        if completion_time_ms is not None and completion_time_ms > 0:
            throughput_bytes_per_sec = (payload_bytes * 1000.0) / completion_time_ms

        results.append(
            StreamMetricsResult(
                stream_id=stream_id,
                request_start_ms=bucket.request_start_ms,
                response_headers_ms=bucket.response_headers_ms,
                stream_end_ms=bucket.stream_end_ms,
                completion_time_ms=completion_time_ms,
                payload_bytes=payload_bytes,
                bytes_sent=bucket.bytes_sent,
                bytes_received=bucket.bytes_received,
                retransmission_events=bucket.retransmission_events,
                throughput_bytes_per_sec=throughput_bytes_per_sec,
            )
        )

    return results


def compute_metrics(trace: QlogTrace) -> MetricsResult:
    start_time = _first_packet_time(trace.events)
    done_time = _handshake_done_time(trace.events)
    handshake_ms: float | None = None
    if start_time is not None and done_time is not None and done_time >= start_time:
        handshake_ms = done_time - start_time

    request_time, response_time = _find_http_markers(trace.events)
    ttfb_ms: float | None = None
    if request_time is not None and response_time is not None and response_time >= request_time:
        ttfb_ms = response_time - request_time

    packet_lost = 0
    packet_dropped = 0
    for ev in trace.events:
        if ev.name in {"recovery:packet_lost", "transport:packet_lost"}:
            packet_lost += 1
        elif ev.name == "transport:packet_dropped":
            packet_dropped += 1

    cwnd_values = _extract_cwnd(trace.events)
    cwnd_first = cwnd_values[0] if cwnd_values else None
    cwnd_last = cwnd_values[-1] if cwnd_values else None
    cwnd_min = min(cwnd_values) if cwnd_values else None
    cwnd_max = max(cwnd_values) if cwnd_values else None

    per_stream = _collect_stream_metrics(trace)

    return MetricsResult(
        source=trace.source.name,
        role=trace.vantage_type,
        total_events=len(trace.events),
        total_streams=len(per_stream),
        handshake_duration_ms=handshake_ms,
        ttfb_ms=ttfb_ms,
        packet_lost_events=packet_lost,
        packet_dropped_events=packet_dropped,
        cwnd_first=cwnd_first,
        cwnd_last=cwnd_last,
        cwnd_min=cwnd_min,
        cwnd_max=cwnd_max,
        per_stream=per_stream,
    )


def compute_metrics_for_input(path: str) -> list[MetricsResult]:
    traces = parse_input(path)
    return [compute_metrics(t) for t in traces]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract metrics from qlog.")
    parser.add_argument("--input", default="sample_logs", help="qlog file or directory")
    return parser


def main() -> None:
    args = _build_parser().parse_args()
    for item in compute_metrics_for_input(args.input):
        print(asdict(item))


if __name__ == "__main__":
    main()

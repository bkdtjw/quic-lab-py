from __future__ import annotations

import argparse
import asyncio
from pathlib import Path
from typing import Any, Awaitable, Callable

from hypercorn.asyncio import serve
from hypercorn.config import Config

from quic_lab.experiments.run_once import load_config
from quic_lab.server.h3_server import build_response_body


async def app(scope: dict[str, Any], receive: Callable[[], Awaitable[dict[str, Any]]], send: Callable[[dict[str, Any]], Awaitable[None]]) -> None:
    if scope["type"] != "http":
        return

    method = scope.get("method", "GET")
    raw_path = scope.get("path", "/")
    query_string = scope.get("query_string", b"")
    if query_string:
        raw_path = f"{raw_path}?{query_string.decode('utf-8', errors='ignore')}"

    if method == "GET":
        body = build_response_body(raw_path)
        status = 200
    else:
        body = b"method not allowed\n"
        status = 405

    headers = [
        (b"server", b"quic-lab-h2"),
        (b"content-type", b"text/plain; charset=utf-8"),
        (b"content-length", str(len(body)).encode("ascii")),
    ]
    await send({"type": "http.response.start", "status": status, "headers": headers})
    await send({"type": "http.response.body", "body": body, "more_body": False})


def build_hypercorn_config(host: str, port: int, cert_path: str, key_path: str) -> Config:
    config = Config()
    config.bind = [f"{host}:{port}"]
    config.certfile = cert_path
    config.keyfile = key_path
    config.alpn_protocols = ["h2", "http/1.1"]
    config.use_reloader = False
    config.worker_class = "asyncio"
    return config


async def run_h2_server(
    host: str,
    port: int,
    cert_path: str,
    key_path: str,
    shutdown_event: asyncio.Event,
) -> None:
    config = build_hypercorn_config(host, port, cert_path, key_path)
    await serve(app, config, shutdown_trigger=shutdown_event.wait)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="HTTP/2 baseline server (TCP+TLS).")
    parser.add_argument("--config", default="config/default.yaml", help="Path to YAML config")
    return parser.parse_args()


async def run() -> None:
    args = parse_args()
    settings = load_config(args.config)
    server_cfg = settings.get("server", {})

    host = str(server_cfg.get("host", "localhost"))
    port = int(server_cfg.get("port", 4433))
    cert_path = str(Path(server_cfg.get("cert", "certs/cert.pem")))
    key_path = str(Path(server_cfg.get("key", "certs/key.pem")))

    shutdown_event = asyncio.Event()
    print(f"[h2-server] listening on https://{host}:{port}")
    try:
        await run_h2_server(
            host=host,
            port=port,
            cert_path=cert_path,
            key_path=key_path,
            shutdown_event=shutdown_event,
        )
    finally:
        shutdown_event.set()


def main() -> None:
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import asyncio
import json
import re
import ssl
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from quic_lab.baseline.h2_server import run_h2_server
from quic_lab.experiments.run_once import load_config


@dataclass
class H2RequestResult:
    path: str
    status_code: int
    bytes_received: int
    ttfb_ms: float
    completion_ms: float


@dataclass
class H2BaselineArtifacts:
    run_id: str
    run_dir: Path
    summary_json_path: Path
    report_text_path: Path
    handshake_ms: float
    negotiated_alpn: str | None
    request_results: list[H2RequestResult]


def _safe_label(label: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z_-]+", "_", label).strip("_")
    return cleaned or "h2"


def _new_run_id(label: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{_safe_label(label)}_{stamp}"


def _resolve_path(path_like: str | Path, base_dir: Path) -> Path:
    path = Path(path_like)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _normalize_paths(path_args: list[str] | None, default_path: str) -> list[str]:
    if not path_args:
        return [default_path]

    paths: list[str] = []
    for raw in path_args:
        for item in raw.split(","):
            path = item.strip()
            if not path:
                continue
            if not path.startswith("/"):
                path = "/" + path
            paths.append(path)
    return paths or [default_path]


def _build_ssl_context(insecure: bool, ca_cert_path: str | None) -> ssl.SSLContext:
    if insecure:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    else:
        context = ssl.create_default_context(cafile=ca_cert_path)
    context.set_alpn_protocols(["h2", "http/1.1"])
    return context


async def _measure_tls_handshake_ms(
    host: str,
    port: int,
    server_name: str,
    insecure: bool,
    ca_cert_path: str | None,
) -> tuple[float, str | None]:
    context = _build_ssl_context(insecure=insecure, ca_cert_path=ca_cert_path)
    start = time.perf_counter()
    open_kwargs = {
        "host": host,
        "port": port,
        "ssl": context,
        "server_hostname": server_name,
        # Reduce IPv6/IPv4 fallback delay on platforms where localhost
        # does not listen on both families.
        "happy_eyeballs_delay": 0.25,
    }
    try:
        reader, writer = await asyncio.open_connection(**open_kwargs)
    except TypeError:
        open_kwargs.pop("happy_eyeballs_delay", None)
        reader, writer = await asyncio.open_connection(**open_kwargs)
    _ = reader
    elapsed_ms = (time.perf_counter() - start) * 1000
    ssl_object = writer.get_extra_info("ssl_object")
    negotiated_alpn = ssl_object.selected_alpn_protocol() if ssl_object else None
    writer.close()
    await writer.wait_closed()
    return elapsed_ms, negotiated_alpn


async def _request_once(client: httpx.AsyncClient, url: str, path: str) -> H2RequestResult:
    started = time.perf_counter()
    first_byte_at: float | None = None
    headers_at: float | None = None
    body_size = 0

    async with client.stream("GET", url) as response:
        headers_at = time.perf_counter()
        async for chunk in response.aiter_bytes():
            if first_byte_at is None:
                first_byte_at = time.perf_counter()
            body_size += len(chunk)
        status_code = response.status_code

    ended = time.perf_counter()
    reference = first_byte_at if first_byte_at is not None else headers_at
    if reference is None:
        reference = ended
    ttfb_ms = (reference - started) * 1000
    completion_ms = (ended - started) * 1000

    return H2RequestResult(
        path=path,
        status_code=status_code,
        bytes_received=body_size,
        ttfb_ms=ttfb_ms,
        completion_ms=completion_ms,
    )


async def _run_h2_requests(
    origin: str,
    paths: list[str],
    insecure: bool,
    ca_cert_path: str | None,
) -> list[H2RequestResult]:
    verify: bool | str
    if insecure:
        verify = False
    else:
        verify = ca_cert_path or True

    limits = httpx.Limits(max_connections=1, max_keepalive_connections=1)
    timeout = httpx.Timeout(timeout=120.0)
    async with httpx.AsyncClient(
        http2=True,
        verify=verify,
        limits=limits,
        timeout=timeout,
        trust_env=False,
    ) as client:
        tasks = [
            asyncio.create_task(_request_once(client, url=f"{origin}{path}", path=path))
            for path in paths
        ]
        return await asyncio.gather(*tasks)


async def _run_h2_baseline_once(
    settings: dict[str, Any],
    base_dir: Path,
    paths: list[str],
    url_override: str | None,
    insecure_override: bool | None,
    ca_cert_override: str | None,
) -> tuple[float, str | None, list[H2RequestResult]]:
    server_cfg = settings.get("server", {})
    client_cfg = settings.get("client", {})

    host = str(server_cfg.get("host", "localhost"))
    port = int(server_cfg.get("port", 4433))
    cert_path = str(_resolve_path(server_cfg.get("cert", "certs/cert.pem"), base_dir))
    key_path = str(_resolve_path(server_cfg.get("key", "certs/key.pem"), base_dir))

    target_url = url_override or client_cfg.get("target", f"https://{host}:{port}/")
    parsed = urlparse(target_url)
    if parsed.scheme != "https":
        raise ValueError("target URL must use https://")
    if not parsed.hostname:
        raise ValueError("target URL is missing host")

    target_host = parsed.hostname
    target_port = parsed.port or 443
    origin = f"https://{parsed.netloc}"

    insecure = bool(client_cfg.get("insecure", False))
    if insecure_override is not None:
        insecure = insecure_override

    ca_cert_path = ca_cert_override or client_cfg.get("ca_cert") or cert_path
    if ca_cert_path is not None:
        ca_cert_path = str(_resolve_path(ca_cert_path, base_dir))

    shutdown_event = asyncio.Event()
    server_task = asyncio.create_task(
        run_h2_server(
            host=host,
            port=port,
            cert_path=cert_path,
            key_path=key_path,
            shutdown_event=shutdown_event,
        )
    )

    try:
        await asyncio.sleep(0.2)
        handshake_ms, negotiated_alpn = await _measure_tls_handshake_ms(
            host=target_host,
            port=target_port,
            server_name=target_host,
            insecure=insecure,
            ca_cert_path=ca_cert_path,
        )
        request_results = await _run_h2_requests(
            origin=origin,
            paths=paths,
            insecure=insecure,
            ca_cert_path=ca_cert_path,
        )
    finally:
        shutdown_event.set()
        await server_task

    return handshake_ms, negotiated_alpn, request_results


def run_h2_baseline(
    config_path: str = "config/default.yaml",
    output_root: str = "output",
    label: str = "h2",
    paths: list[str] | None = None,
    url_override: str | None = None,
    insecure_override: bool | None = None,
    ca_cert_override: str | None = None,
) -> H2BaselineArtifacts:
    base_dir = Path.cwd()
    settings = load_config(config_path)

    target_url = url_override or settings.get("client", {}).get("target", "https://localhost:4433/")
    parsed = urlparse(target_url)
    default_path = parsed.path or "/"
    if parsed.query:
        default_path = f"{default_path}?{parsed.query}"
    selected_paths = _normalize_paths(paths, default_path=default_path)

    run_id = _new_run_id(label)
    run_dir = _resolve_path(Path(output_root) / "baseline_h2" / run_id, base_dir)
    run_dir.mkdir(parents=True, exist_ok=True)

    handshake_ms, negotiated_alpn, request_results = asyncio.run(
        _run_h2_baseline_once(
            settings=settings,
            base_dir=base_dir,
            paths=selected_paths,
            url_override=url_override,
            insecure_override=insecure_override,
            ca_cert_override=ca_cert_override,
        )
    )

    summary_json_path = run_dir / "summary.json"
    report_text_path = run_dir / "report.txt"

    summary_json_path.write_text(
        json.dumps(
            {
                "run_id": run_id,
                "protocol": "h2",
                "handshake_ms": handshake_ms,
                "negotiated_alpn": negotiated_alpn,
                "requests": [asdict(item) for item in request_results],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    lines = [
        f"run_id: {run_id}",
        f"protocol: h2",
        f"handshake_ms: {handshake_ms:.3f}",
        f"negotiated_alpn: {negotiated_alpn}",
        "",
        "path | status | bytes | ttfb_ms | completion_ms",
        "---|---:|---:|---:|---:",
    ]
    for item in request_results:
        lines.append(
            f"{item.path} | {item.status_code} | {item.bytes_received} | "
            f"{item.ttfb_ms:.3f} | {item.completion_ms:.3f}"
        )
    report_text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    return H2BaselineArtifacts(
        run_id=run_id,
        run_dir=run_dir,
        summary_json_path=summary_json_path,
        report_text_path=report_text_path,
        handshake_ms=handshake_ms,
        negotiated_alpn=negotiated_alpn,
        request_results=request_results,
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run HTTP/2 baseline client+server experiment.")
    parser.add_argument("--config", default="config/default.yaml", help="Path to YAML config")
    parser.add_argument("--output-root", default="output", help="Output root directory")
    parser.add_argument("--label", default="h2", help="Run label in output folder name")
    parser.add_argument("--path", action="append", help="Request path (repeatable or comma-separated)")
    parser.add_argument("--url", help="Override client target URL")
    parser.add_argument("--insecure", action="store_true", help="Disable certificate verification")
    parser.add_argument("--ca-cert", help="Override CA certificate path")
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = _build_parser()
    args = parser.parse_args(argv)

    artifacts = run_h2_baseline(
        config_path=args.config,
        output_root=args.output_root,
        label=args.label,
        paths=args.path,
        url_override=args.url,
        insecure_override=True if args.insecure else None,
        ca_cert_override=args.ca_cert,
    )

    print(f"[h2] completed: {artifacts.run_id}")
    print(f"[h2] handshake_ms: {artifacts.handshake_ms:.3f}")
    print(f"[h2] alpn: {artifacts.negotiated_alpn}")
    for item in artifacts.request_results:
        print(
            f"[h2] path={item.path} status={item.status_code} "
            f"bytes={item.bytes_received} ttfb_ms={item.ttfb_ms:.3f} "
            f"completion_ms={item.completion_ms:.3f}"
        )
    print(f"[h2] summary: {artifacts.summary_json_path}")


if __name__ == "__main__":
    main()

"""TCP/TLS + HTTP/2 baseline implementation for protocol comparison."""

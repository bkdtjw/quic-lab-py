import argparse
import asyncio
import json
import ssl
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple
from urllib.parse import urlparse

import yaml
from aioquic.asyncio.client import connect
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.h3.connection import H3_ALPN, H3Connection
from aioquic.h3.events import DataReceived, HeadersReceived, H3Event
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.logger import QuicLogger


@dataclass
class ResponseBuffer:
    """缓存单个请求流的响应数据。"""

    stream_id: int
    path: str
    headers: List[Tuple[bytes, bytes]] = field(default_factory=list)
    body: bytearray = field(default_factory=bytearray)
    finished: asyncio.Event = field(default_factory=asyncio.Event)
    started_at: float = field(default_factory=time.perf_counter)
    ended_at: float | None = None


class SimpleH3Client(QuicConnectionProtocol):
    """最小 HTTP/3 客户端协议：发送 GET 并收集响应。"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._h3 = H3Connection(self._quic)
        self._responses: Dict[int, ResponseBuffer] = {}

    async def get(self, authority: str, path: str) -> ResponseBuffer:
        # 1) 新开一个双向流，存放本次请求的响应缓存
        stream_id = self._quic.get_next_available_stream_id()
        response = ResponseBuffer(stream_id=stream_id, path=path)
        self._responses[stream_id] = response

        # 2) 发送 HTTP/3 请求头（伪首部 + 普通首部）
        headers = [
            (b":method", b"GET"),
            (b":scheme", b"https"),
            (b":authority", authority.encode("utf-8")),
            (b":path", path.encode("utf-8")),
            (b"user-agent", b"quic-lab-simple-client"),
        ]
        self._h3.send_headers(stream_id=stream_id, headers=headers, end_stream=True)
        self.transmit()

        # 3) 等待该流收完响应
        await response.finished.wait()
        return response

    async def get_many(self, authority: str, paths: List[str]) -> List[ResponseBuffer]:
        tasks = [asyncio.create_task(self.get(authority=authority, path=path)) for path in paths]
        return await asyncio.gather(*tasks)

    def quic_event_received(self, event) -> None:
        # QUIC 层事件继续交给 H3 层解析
        for http_event in self._h3.handle_event(event):
            self._handle_http_event(http_event)

    def _handle_http_event(self, http_event: H3Event) -> None:
        if isinstance(http_event, HeadersReceived):
            response = self._responses.get(http_event.stream_id)
            if response:
                response.headers.extend(http_event.headers)
                if http_event.stream_ended:
                    response.ended_at = time.perf_counter()
                    response.finished.set()

        elif isinstance(http_event, DataReceived):
            response = self._responses.get(http_event.stream_id)
            if response:
                response.body.extend(http_event.data)
                if http_event.stream_ended:
                    response.ended_at = time.perf_counter()
                    response.finished.set()


def get_header_value(response: ResponseBuffer, name: str) -> str | None:
    key = name.encode("utf-8")
    for header_key, header_value in response.headers:
        if header_key == key:
            return header_value.decode("utf-8", errors="ignore")
    return None


def build_path(parsed) -> str:
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return path


def load_config(config_path: str) -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data


def write_qlog(quic_logger: QuicLogger, qlog_dir: Path, role: str) -> Path:
    qlog_dir.mkdir(parents=True, exist_ok=True)
    file_path = qlog_dir / f"{role}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.qlog"
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(quic_logger.to_dict(), f, ensure_ascii=False, indent=2)
    return file_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="简单 HTTP/3 客户端示例（中文注释版）")
    parser.add_argument("--config", default="config/default.yaml", help="配置文件路径")
    parser.add_argument("--url", help="目标 URL（优先级高于配置文件）")
    parser.add_argument(
        "--path",
        action="append",
        help="在同一条连接上并发请求的路径，可重复传入。示例: --path /large?bytes=1048576 --path /small",
    )
    parser.add_argument(
        "--insecure",
        action="store_true",
        help="忽略服务端证书校验（仅建议本地实验使用）",
    )
    parser.add_argument("--ca-cert", help="自定义 CA 证书路径（PEM）")
    return parser.parse_args()


async def run() -> None:
    args = parse_args()
    settings = load_config(args.config)
    server_cfg = settings.get("server", {})
    client_cfg = settings.get("client", {})
    logging_cfg = settings.get("logging", {})

    target_url = args.url or client_cfg.get("target", "https://localhost:4433/")
    parsed = urlparse(target_url)

    if parsed.scheme != "https":
        raise ValueError("HTTP/3 需要 https:// URL")
    if not parsed.hostname:
        raise ValueError("URL 缺少主机名")

    host = parsed.hostname
    port = parsed.port or 443
    authority = parsed.netloc
    path = build_path(parsed)

    qlog_dir = Path(logging_cfg.get("qlog_dir", "output/qlogs"))
    quic_logger = QuicLogger()
    config = QuicConfiguration(
        alpn_protocols=H3_ALPN,
        is_client=True,
        quic_logger=quic_logger,
        server_name=host,
    )

    insecure = args.insecure or bool(client_cfg.get("insecure", False))
    ca_cert = args.ca_cert or client_cfg.get("ca_cert") or server_cfg.get("cert")

    if insecure:
        config.verify_mode = ssl.CERT_NONE
    elif ca_cert:
        config.load_verify_locations(ca_cert)

    async with connect(
        host=host,
        port=port,
        configuration=config,
        create_protocol=SimpleH3Client,
        wait_connected=True,
    ) as protocol:
        client = protocol
        request_paths = args.path or [path]
        responses = await client.get_many(authority=authority, paths=request_paths)

    if len(responses) == 1:
        response = responses[0]
        print("=== 响应头 ===")
        for key, value in response.headers:
            print(f"{key.decode('utf-8', errors='ignore')}: {value.decode('utf-8', errors='ignore')}")
        print("\n=== 响应体 ===")
        print(response.body.decode("utf-8", errors="replace"))
    else:
        print("=== 并发请求结果 ===")
        for response in responses:
            status = get_header_value(response, ":status") or "N/A"
            elapsed_ms = None
            if response.ended_at is not None:
                elapsed_ms = (response.ended_at - response.started_at) * 1000
            elapsed_text = f"{elapsed_ms:.2f} ms" if elapsed_ms is not None else "N/A"
            print(
                f"stream={response.stream_id} path={response.path} "
                f"status={status} bytes={len(response.body)} elapsed={elapsed_text}"
            )

    qlog_path = write_qlog(quic_logger=quic_logger, qlog_dir=qlog_dir, role="client")
    print(f"\n[client] qlog written: {qlog_path}")


if __name__ == "__main__":
    asyncio.run(run())

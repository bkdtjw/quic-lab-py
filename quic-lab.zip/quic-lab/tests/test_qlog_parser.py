from __future__ import annotations

import json
from pathlib import Path

from quic_lab.analyzer.metrics import compute_metrics_for_input
from quic_lab.analyzer.qlog_parser import parse_input
from quic_lab.analyzer.report import build_markdown_report, build_text_report


SAMPLE_DIR = Path("sample_logs")


def test_parse_sample_logs() -> None:
    traces = parse_input(SAMPLE_DIR)
    assert len(traces) >= 2
    assert all(len(t.events) > 0 for t in traces)
    roles = {t.vantage_type for t in traces}
    assert "client" in roles
    assert "server" in roles


def test_metrics_extraction() -> None:
    metrics = compute_metrics_for_input(str(SAMPLE_DIR))
    assert len(metrics) >= 2

    client_items = [m for m in metrics if m.role == "client"]
    assert client_items, "missing client metrics"

    client = client_items[0]
    assert client.handshake_duration_ms is not None
    assert client.handshake_duration_ms >= 0
    assert client.ttfb_ms is not None
    assert client.ttfb_ms >= 0
    assert client.cwnd_first is not None
    assert client.cwnd_last is not None
    assert client.packet_dropped_events >= 0
    assert client.total_streams >= 1
    assert client.per_stream

    first_stream = client.per_stream[0]
    assert first_stream.stream_id >= 0
    assert first_stream.payload_bytes >= 0
    assert first_stream.bytes_received >= 0
    assert first_stream.bytes_sent >= 0


def test_report_rendering() -> None:
    metrics = compute_metrics_for_input(str(SAMPLE_DIR))
    text_report = build_text_report(metrics)
    md_report = build_markdown_report(metrics)

    assert "source" in text_report
    assert "handshake_ms" in text_report
    assert "| source | role | events |" in md_report


def test_sample_qlog_standard_shape() -> None:
    qlog_files = sorted(SAMPLE_DIR.glob("*.qlog"))
    assert qlog_files, "no sample qlog files found"

    for qlog_path in qlog_files:
        payload = json.loads(qlog_path.read_text(encoding="utf-8"))
        assert isinstance(payload, dict)
        assert "qlog_format" in payload
        assert "qlog_version" in payload
        assert "traces" in payload

        traces = payload["traces"]
        assert isinstance(traces, list)
        assert traces, f"{qlog_path.name} has no traces"

        trace = traces[0]
        assert "events" in trace
        events = trace["events"]
        assert isinstance(events, list)
        assert events, f"{qlog_path.name} has empty events"

        first_event = events[0]
        assert "name" in first_event
        assert "time" in first_event

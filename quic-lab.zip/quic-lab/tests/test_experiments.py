from __future__ import annotations

import socket
import uuid
from pathlib import Path
import shutil

import pytest
import yaml

from quic_lab.experiments import compare as compare_mod
from quic_lab.experiments import multiplexing as multiplex_mod
from quic_lab.experiments import run_once as run_once_mod
from quic_lab.experiments import weak_network as weak_mod


def _get_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _write_temp_config(work_dir: Path) -> Path:
    repo_root = Path(__file__).resolve().parents[1]
    cert_path = (repo_root / "certs" / "cert.pem").resolve()
    key_path = (repo_root / "certs" / "key.pem").resolve()
    port = _get_free_port()

    config = {
        "server": {
            "host": "localhost",
            "port": port,
            "cert": str(cert_path),
            "key": str(key_path),
        },
        "client": {
            "target": f"https://localhost:{port}/",
            "ca_cert": str(cert_path),
            "insecure": False,
        },
        "logging": {"qlog_dir": "output/qlogs"},
        "experiments": {"repeat": 1},
    }

    config_path = work_dir / "config.yaml"
    config_path.write_text(yaml.safe_dump(config), encoding="utf-8")
    return config_path


def test_run_once_creates_artifacts() -> None:
    work_dir = Path("output") / "test_tmp" / f"run_once_{uuid.uuid4().hex}"
    work_dir.mkdir(parents=True, exist_ok=True)
    config_path = _write_temp_config(work_dir)
    output_root = work_dir / "out"

    try:
        artifacts = run_once_mod.run_once(
            config_path=str(config_path),
            output_root=str(output_root),
            label="pytest",
        )

        assert artifacts.response_status == "200"
        assert artifacts.report_text_path.exists()
        assert artifacts.report_markdown_path.exists()
        assert artifacts.metrics_json_path.exists()
        assert artifacts.summary_json_path.exists()
        assert len(list(artifacts.qlog_dir.glob("*.qlog"))) >= 2
        assert len(artifacts.metrics) >= 2
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def test_compare_markdown_builder() -> None:
    rendered = compare_mod._build_markdown(
        [
            compare_mod.ComparisonRow(
                scenario="baseline",
                round=1,
                protocol="quic",
                status="200",
                handshake_ms=1.0,
                avg_completion_ms=2.0,
                avg_ttfb_ms=1.2,
                recovery_ms=0.8,
                packet_dropped=1,
                retransmission_events=0,
                run_dir="output/runs/example",
            )
        ],
    )
    assert "| scenario | round | protocol |" in rendered
    assert "baseline" in rendered


def test_run_multiplexing_creates_per_stream_metrics() -> None:
    work_dir = Path("output") / "test_tmp" / f"multiplex_{uuid.uuid4().hex}"
    work_dir.mkdir(parents=True, exist_ok=True)
    config_path = _write_temp_config(work_dir)
    output_root = work_dir / "out"

    try:
        artifacts = multiplex_mod.run_multiplexing(
            config_path=str(config_path),
            output_root=str(output_root),
            label="pytest_multiplex",
            paths=[
                "/large?bytes=65536",
                "/small?bytes=512",
                "/small?bytes=256",
            ],
        )

        assert artifacts.stream_results
        assert len(artifacts.stream_results) == 3
        assert artifacts.metrics_json_path.exists()
        assert artifacts.report_text_path.exists()
        assert len(list(artifacts.qlog_dir.glob("*.qlog"))) >= 2

        client_metrics = [m for m in artifacts.metrics if m.role == "client"]
        assert client_metrics
        client_metric = client_metrics[0]
        assert client_metric.total_streams >= 3
        assert len(client_metric.per_stream) >= 3
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def test_apply_profile_builds_tc_command(monkeypatch: pytest.MonkeyPatch) -> None:
    commands: list[list[str]] = []

    monkeypatch.setattr(weak_mod.platform, "system", lambda: "Linux")
    monkeypatch.setattr(weak_mod.shutil, "which", lambda _: "/sbin/tc")

    def fake_run(cmd, check=True, **kwargs):
        commands.append(cmd)
        return object()

    monkeypatch.setattr(weak_mod.subprocess, "run", fake_run)

    weak_mod.apply_profile(
        "lo",
        weak_mod.NetemProfile(delay_ms=50, loss_pct=1.5, rate_kbit=4000),
    )

    assert commands
    assert commands[0] == [
        "tc",
        "qdisc",
        "replace",
        "dev",
        "lo",
        "root",
        "netem",
        "delay",
        "50ms",
        "loss",
        "1.5%",
        "rate",
        "4000kbit",
    ]


def test_weak_network_main_non_linux(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(weak_mod.platform, "system", lambda: "Windows")
    with pytest.raises(SystemExit) as exc:
        weak_mod.main(["show"])
    assert "only supported on Linux" in str(exc.value)


def test_compare_protocol_parser() -> None:
    assert compare_mod._parse_protocols("quic,h2") == ["quic", "h2"]
    assert compare_mod._parse_protocols("h2,quic,h2") == ["h2", "quic"]
    with pytest.raises(ValueError):
        compare_mod._parse_protocols("quic,foo")

from __future__ import annotations

from quic_lab import __main__ as cli


def test_cli_dispatch_run(monkeypatch) -> None:
    called = {}

    def fake_run(argv):
        called["cmd"] = "run"
        called["argv"] = argv

    monkeypatch.setattr(cli, "run_once_main", fake_run)
    cli.main(["run", "--config", "x.yaml"])

    assert called["cmd"] == "run"
    assert called["argv"] == ["--config", "x.yaml"]


def test_cli_dispatch_compare(monkeypatch) -> None:
    called = {}

    def fake_compare(argv):
        called["cmd"] = "compare"
        called["argv"] = argv

    monkeypatch.setattr(cli, "compare_main", fake_compare)
    cli.main(["compare", "--rounds", "2"])

    assert called["cmd"] == "compare"
    assert called["argv"] == ["--rounds", "2"]


def test_cli_dispatch_multiplexing(monkeypatch) -> None:
    called = {}

    def fake_multiplexing(argv):
        called["cmd"] = "multiplexing"
        called["argv"] = argv

    monkeypatch.setattr(cli, "multiplexing_main", fake_multiplexing)
    cli.main(["multiplexing", "--path", "/large"])

    assert called["cmd"] == "multiplexing"
    assert called["argv"] == ["--path", "/large"]


def test_cli_dispatch_weak_network(monkeypatch) -> None:
    called = {}

    def fake_weak(argv):
        called["cmd"] = "weak-network"
        called["argv"] = argv

    monkeypatch.setattr(cli, "weak_network_main", fake_weak)
    cli.main(["weak-network", "show"])

    assert called["cmd"] == "weak-network"
    assert called["argv"] == ["show"]

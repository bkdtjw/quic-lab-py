# Design Overview

## Goals

- Keep the project easy to teach and easy to extend.
- Keep each stage testable in isolation.
- Support both manual analysis and one-command automation.

## Modules

| Module | Responsibility |
|---|---|
| `quic_lab.server.h3_server` | Minimal HTTP/3 server, fixed response, server qlog writing |
| `quic_lab.client.h3_client` | Minimal HTTP/3 client, request/response handling, client qlog writing |
| `quic_lab.analyzer.qlog_parser` | Parse qlog files into normalized trace/event structures |
| `quic_lab.analyzer.metrics` | Extract key metrics from parsed events |
| `quic_lab.analyzer.report` | Render text/markdown reports from metrics |
| `quic_lab.experiments.run_once` | Orchestrate one full experiment end-to-end |
| `quic_lab.experiments.weak_network` | Manage Linux `tc netem` profiles |
| `quic_lab.experiments.compare` | Run multiple scenarios and aggregate comparison results |
| `quic_lab.__main__` | CLI router for `run`, `weak-network`, and `compare` |

## End-to-End Data Flow

```mermaid
flowchart LR
    A["config/default.yaml"] --> B["run_once"]
    B --> C["start server (aioquic)"]
    B --> D["run client (aioquic)"]
    C --> E["server qlog"]
    D --> F["client qlog"]
    E --> G["qlog_parser"]
    F --> G
    G --> H["metrics"]
    H --> I["report (text/md)"]
    H --> J["metrics.json"]
```

## Output Contract

Each `run` writes:

- `output/runs/<run_id>/qlogs/*.qlog`
- `output/runs/<run_id>/report.txt`
- `output/runs/<run_id>/report.md`
- `output/runs/<run_id>/metrics.json`
- `output/runs/<run_id>/summary.json`

Each `compare` writes:

- `output/compare/<compare_id>/summary.md`
- `output/compare/<compare_id>/summary.json`

## Configuration Contract

`config/default.yaml` currently controls:

- `server.host`, `server.port`, `server.cert`, `server.key`
- `client.target`, `client.ca_cert`, `client.insecure`
- `logging.qlog_dir`
- `experiments.repeat` and optional `experiments.profiles`

## Design Tradeoffs

- `run_once` starts server/client in one process to make `python -m quic_lab run` deterministic and simple.
- qlog writing is explicit in code instead of relying on external tooling.
- weak-network support is Linux-only by design (`tc netem`), with graceful degradation on other OSes.
- metrics are computed from qlog event patterns, so they stay reproducible from recorded data.

## Extension Points

- Add richer HTTP workloads in client/server (streaming, concurrent requests).
- Add more metrics in `metrics.py` (retransmission rate, RTT percentiles).
- Add chart export in `report.py`.
- Add new scenario types in `compare.py` (bandwidth profile sweeps, retries, load levels).

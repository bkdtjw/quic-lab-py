# QUIC / HTTP3 Protocol Notes

This document captures protocol understanding used in this lab implementation.

## 1. Why QUIC in This Project

- QUIC runs over UDP and integrates TLS 1.3 handshake.
- Connection setup and transport security happen together.
- Packet number spaces and stream multiplexing reduce head-of-line blocking.
- HTTP/3 maps requests to QUIC streams with QPACK header compression.

## 2. Handshake Observability in QLOG

In this project, handshake timing is inferred from qlog events:

1. Start reference: first `transport:packet_sent` or `transport:packet_received`.
2. Completion reference:
   - Prefer `transport:packet_received` containing `handshake_done` frame.
   - Fallback to first `security:key_updated` event whose `key_type` includes `1rtt`.

`handshake_duration_ms = completion_time - start_time`

Notes:

- Client and server perspectives are different, so handshake durations are expected to differ.
- Values are local-timeline measurements, not synchronized wall-clock between endpoints.

## 3. TTFB in This Lab

TTFB is derived from HTTP frame events:

1. Request marker: first HTTP headers frame carrying `:method`.
2. Response marker: first HTTP headers frame carrying `:status`.

`ttfb_ms = response_headers_time - request_headers_time`

Notes:

- This is application-level first-byte timing by qlog event order.
- It does not directly include client rendering or downstream processing overhead.

## 4. Loss / Drop Signals

Current metric extraction uses:

- `recovery:packet_lost` or `transport:packet_lost` -> packet loss count.
- `transport:packet_dropped` -> dropped packet count.

Interpretation:

- `packet_dropped` can include parsing or policy drops, not only channel loss.
- Weak-network injection can increase both counts depending on condition and endpoint behavior.

## 5. Congestion Window (cwnd) Tracking

From `recovery:metrics_updated` events:

- collect `cwnd` samples in timestamp order.
- expose `cwnd_first`, `cwnd_last`, `cwnd_min`, `cwnd_max`.

This gives a simple trend snapshot:

- early growth and steady-state behavior.
- whether congestion control reacted to adverse conditions.

## 6. HTTP/3 Mapping in Current Minimal Flow

- Client sends one GET request on a single bidirectional stream.
- Server returns status + plaintext body, then stream ends.
- qlog records both transport and HTTP-layer events, enabling cross-layer analysis.

## 7. Limits and Next Improvements

Current limits:

- Single request per run.
- No explicit RTT percentile extraction.
- No retransmission-rate or goodput metrics.

Recommended next steps:

- multi-request workloads with concurrency.
- richer metrics (RTT distribution, ack dynamics, retransmission ratio).
- plotting support for cwnd/RTT over time.

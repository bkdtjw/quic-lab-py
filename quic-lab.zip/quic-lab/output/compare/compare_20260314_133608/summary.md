| scenario | round | status | handshake_ms | ttfb_ms | packet_dropped | cwnd_first | cwnd_last | run_dir |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| baseline | 1 | 200 | 4.698 | 0.781 | 1 | 12000 | 13632 | C:\Users\nirvana\Desktop\quic-lab\output\runs\baseline_r1_20260314_133608 |
| delay_50ms | 1 | 200 | 3.792 | 0.704 | 1 | 12000 | 13667 | C:\Users\nirvana\Desktop\quic-lab\output\runs\delay_50ms_r1_20260314_133609 |
| loss_1pct | 1 | 200 | 2.729 | 0.777 | 1 | 12000 | 13667 | C:\Users\nirvana\Desktop\quic-lab\output\runs\loss_1pct_r1_20260314_133609 |

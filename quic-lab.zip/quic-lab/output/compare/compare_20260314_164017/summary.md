| scenario | round | protocol | status | handshake_ms | avg_completion_ms | avg_ttfb_ms | recovery_ms | packet_dropped | retransmissions | run_dir |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| baseline | 1 | quic | 200 | 4.208 | 1.214 | 0.938 | 0.475 | 1 | 0 | C:\Users\nirvana\Desktop\quic-lab\output\multiplexing\baseline_quic_r1_20260314_164017 |
| baseline | 1 | h2 | 200 | 262.559 | 283.899 | 282.002 | 2.589 | N/A | N/A | C:\Users\nirvana\Desktop\quic-lab\output\baseline_h2\baseline_h2_r1_20260314_164017 |
| delay_50ms | 1 | quic | 200 | 4.804 | 1.978 | 1.619 | 0.655 | 1 | 0 | C:\Users\nirvana\Desktop\quic-lab\output\multiplexing\delay_50ms_quic_r1_20260314_164018 |
| delay_50ms | 1 | h2 | 200 | 265.949 | 267.965 | 266.652 | 0.164 | N/A | N/A | C:\Users\nirvana\Desktop\quic-lab\output\baseline_h2\delay_50ms_h2_r1_20260314_164018 |
| loss_1pct | 1 | quic | 200 | 3.748 | 1.123 | 0.799 | 0.582 | 1 | 0 | C:\Users\nirvana\Desktop\quic-lab\output\multiplexing\loss_1pct_quic_r1_20260314_164019 |
| loss_1pct | 1 | h2 | 200 | 265.891 | 269.591 | 268.375 | 0.002 | N/A | N/A | C:\Users\nirvana\Desktop\quic-lab\output\baseline_h2\loss_1pct_h2_r1_20260314_164019 |

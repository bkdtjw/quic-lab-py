| scenario | round | status | handshake_ms | ttfb_ms | packet_dropped | cwnd_first | cwnd_last | run_dir |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| baseline | 1 | 200 | 4.096 | 0.717 | 1 | 12000 | 13632 | C:\Users\nirvana\Desktop\quic-lab\output\runs\baseline_r1_20260314_133745 |
| delay_50ms | 1 | 200 | 3.163 | 0.570 | 1 | 12000 | 12518 | C:\Users\nirvana\Desktop\quic-lab\output\runs\delay_50ms_r1_20260314_133745 |
| loss_1pct | 1 | 200 | 2.848 | 0.580 | 1 | 12000 | 12518 | C:\Users\nirvana\Desktop\quic-lab\output\runs\loss_1pct_r1_20260314_133745 |

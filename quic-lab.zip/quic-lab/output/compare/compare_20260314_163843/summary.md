| scenario | round | protocol | status | handshake_ms | avg_completion_ms | avg_ttfb_ms | recovery_ms | packet_dropped | retransmissions | run_dir |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| baseline | 1 | quic | 200 | 3.627 | 1.267 | 1.002 | 0.454 | 1 | 0 | C:\Users\nirvana\Desktop\quic-lab\output\multiplexing\baseline_quic_r1_20260314_163843 |
| baseline | 1 | h2 | 200 | 2033.021 | 276.417 | 275.387 | 3.634 | N/A | N/A | C:\Users\nirvana\Desktop\quic-lab\output\baseline_h2\baseline_h2_r1_20260314_163843 |
| delay_50ms | 1 | quic | 200 | 3.564 | 1.478 | 1.202 | 0.512 | 1 | 0 | C:\Users\nirvana\Desktop\quic-lab\output\multiplexing\delay_50ms_quic_r1_20260314_163845 |
| delay_50ms | 1 | h2 | 200 | 2046.536 | 267.560 | 266.568 | 0.409 | N/A | N/A | C:\Users\nirvana\Desktop\quic-lab\output\baseline_h2\delay_50ms_h2_r1_20260314_163845 |
| loss_1pct | 1 | quic | 200 | 4.022 | 1.028 | 0.723 | 0.565 | 1 | 0 | C:\Users\nirvana\Desktop\quic-lab\output\multiplexing\loss_1pct_quic_r1_20260314_163848 |
| loss_1pct | 1 | h2 | 200 | 2048.245 | 290.080 | 287.184 | 0.622 | N/A | N/A | C:\Users\nirvana\Desktop\quic-lab\output\baseline_h2\loss_1pct_h2_r1_20260314_163848 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133609.qlog | client | 53 | 4.698 | 0.781 | 0 | 1 | 12000 | 13632 | 12000 | 13632 |
| server_20260314_133609.qlog | server | 52 | 0.856 | 0.023 | 0 | 1 | 12000 | 12811 | 12000 | 12811 |

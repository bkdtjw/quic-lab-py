| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133609.qlog | client | 56 | 2.729 | 0.777 | 0 | 1 | 12000 | 13667 | 12000 | 13667 |
| server_20260314_133609.qlog | server | 54 | 0.423 | 0.021 | 0 | 1 | 12000 | 12812 | 12000 | 12812 |

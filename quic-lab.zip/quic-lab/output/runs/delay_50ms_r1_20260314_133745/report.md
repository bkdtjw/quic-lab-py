| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133745.qlog | client | 52 | 3.163 | 0.570 | 0 | 1 | 12000 | 12518 | 12000 | 12518 |
| server_20260314_133745.qlog | server | 54 | 0.439 | 0.015 | 0 | 1 | 12000 | 12810 | 12000 | 12810 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133556.qlog | client | 55 | 9.456 | 2.198 | 0 | 1 | 12000 | 13632 | 12000 | 13632 |
| server_20260314_133556.qlog | server | 56 | 2.152 | 0.110 | 0 | 1 | 12000 | 13177 | 12000 | 13177 |

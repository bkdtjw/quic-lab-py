| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133745.qlog | client | 52 | 2.848 | 0.580 | 0 | 1 | 12000 | 12518 | 12000 | 12518 |
| server_20260314_133745.qlog | server | 54 | 0.453 | 0.015 | 0 | 1 | 12000 | 12811 | 12000 | 12811 |

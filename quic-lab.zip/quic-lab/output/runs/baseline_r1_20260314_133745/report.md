| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133745.qlog | client | 56 | 4.096 | 0.717 | 0 | 1 | 12000 | 13632 | 12000 | 13632 |
| server_20260314_133745.qlog | server | 54 | 0.758 | 0.023 | 0 | 1 | 12000 | 12811 | 12000 | 12811 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_133904.qlog | client | 56 | 4.123 | 0.691 | 0 | 1 | 12000 | 13632 | 12000 | 13632 |
| server_20260314_133904.qlog | server | 54 | 0.709 | 0.021 | 0 | 1 | 12000 | 12812 | 12000 | 12812 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_163845.qlog | client | 83 | 3.564 | 1.202 | 0 | 1 | 12000 | 13803 | 12000 | 13803 |
| server_20260314_163845.qlog | server | 81 | 0.526 | 0.034 | 0 | 1 | 12000 | 13065 | 12000 | 13065 |

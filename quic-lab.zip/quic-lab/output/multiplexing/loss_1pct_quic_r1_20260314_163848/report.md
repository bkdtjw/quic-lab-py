| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_163848.qlog | client | 79 | 4.022 | 0.723 | 0 | 1 | 12000 | 13680 | 12000 | 13680 |
| server_20260314_163848.qlog | server | 79 | 0.690 | 0.031 | 0 | 1 | 12000 | 13394 | 12000 | 13394 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_142102.qlog | client | 259 | 4.260 | 1.232 | 0 | 1 | 12000 | 13890 | 12000 | 13890 |
| server_20260314_142102.qlog | server | 268 | 0.824 | 0.052 | 0 | 1 | 12000 | 77460 | 12000 | 77460 |

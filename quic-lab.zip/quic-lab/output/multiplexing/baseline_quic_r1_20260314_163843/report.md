| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_163843.qlog | client | 83 | 3.627 | 1.002 | 0 | 1 | 12000 | 13803 | 12000 | 13803 |
| server_20260314_163843.qlog | server | 81 | 0.703 | 0.041 | 0 | 1 | 12000 | 13065 | 12000 | 13065 |

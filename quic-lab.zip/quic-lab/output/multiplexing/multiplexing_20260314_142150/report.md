| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_142150.qlog | client | 174 | 4.148 | 1.344 | 0 | 1 | 12000 | 13890 | 12000 | 13890 |
| server_20260314_142150.qlog | server | 178 | 0.708 | 0.048 | 0 | 1 | 12000 | 47789 | 12000 | 47789 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_164019.qlog | client | 80 | 3.748 | 0.799 | 0 | 1 | 12000 | 13803 | 12000 | 13803 |
| server_20260314_164019.qlog | server | 79 | 0.475 | 0.032 | 0 | 1 | 12000 | 13399 | 12000 | 13399 |

| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_164017.qlog | client | 83 | 4.208 | 0.938 | 0 | 1 | 12000 | 13803 | 12000 | 13803 |
| server_20260314_164017.qlog | server | 81 | 0.885 | 0.042 | 0 | 1 | 12000 | 13395 | 12000 | 13395 |

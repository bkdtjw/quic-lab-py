| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_163819.qlog | client | 83 | 3.778 | 1.019 | 0 | 1 | 12000 | 13803 | 12000 | 13803 |
| server_20260314_163819.qlog | server | 81 | 0.708 | 0.042 | 0 | 1 | 12000 | 13064 | 12000 | 13064 |

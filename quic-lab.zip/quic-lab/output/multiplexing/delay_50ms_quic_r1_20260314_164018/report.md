| source | role | events | handshake_ms | ttfb_ms | packet_lost | packet_dropped | cwnd_first | cwnd_last | cwnd_min | cwnd_max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| client_20260314_164018.qlog | client | 80 | 4.804 | 1.619 | 0 | 1 | 12000 | 13770 | 12000 | 13770 |
| server_20260314_164018.qlog | server | 79 | 0.656 | 0.051 | 0 | 1 | 12000 | 13064 | 12000 | 13064 |
